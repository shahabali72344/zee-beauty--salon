/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Scissors,
  Sparkles,
  Droplets,
  Heart,
  Palette,
  Star,
  MapPin,
  Phone,
  Mail,
  MessageCircle,
  Menu,
  X,
  ChevronUp,
  Camera,
  Gem,
  Clock
} from 'lucide-react';

export default function App() {
  const [showTopBtn, setShowTopBtn] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowTopBtn(true);
      } else {
        setShowTopBtn(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const goToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'Contact', href: '#contact' },
  ];

  const services = [
    { icon: <Scissors size={18} />, title: "Hair Styling", desc: "Professional cuts & color styling." },
    { icon: <Gem size={18} />, title: "Bridal Makeup", desc: "Exquisite and elegant wedding looks." },
    { icon: <Droplets size={18} />, title: "Facial Spa", desc: "Deep cleansing and radiant glow." },
    { icon: <Sparkles size={18} />, title: "Manicure", desc: "Classic nail care and premium polish." },
    { icon: <Palette size={18} />, title: "Hair Coloring", desc: "Balayage, highlights & tints." },
    { icon: <Star size={18} />, title: "Party Makeup", desc: "Glamorous, long-lasting looks." },
    { icon: <Heart size={18} />, title: "Pedicure", desc: "Relaxing foot baths and grooming." },
    { icon: <Clock size={18} />, title: "Skin Care", desc: "Rejuvenating therapies." },
  ];

  const galleryImages = [
    "https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=500&q=80",
    "https://images.unsplash.com/photo-1600948836101-f9ffda59d250?auto=format&fit=crop&w=500&q=80",
    "https://images.unsplash.com/photo-1521590832167-7bfcfaa6362f?auto=format&fit=crop&w=500&q=80",
    "https://images.unsplash.com/photo-1516975080661-46eaf8d1fa65?auto=format&fit=crop&w=500&q=80",
    "https://images.unsplash.com/photo-1633681926022-84c23e8cb2d6?auto=format&fit=crop&w=500&q=80",
    "https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=500&q=80"
  ];

  const pricing = [
    { name: "Basic Trim & Style", price: "$49", features: ["Consultation", "Hair Wash", "Basic Trim", "Blow Dry"] },
    { name: "Premium Glow", price: "$129", bg: "bg-pink-500", text: "text-white", border: "border-pink-500", features: ["Deep Cleansing Facial", "Hair Spa", "Professional Styling", "Basic Manicure"], popular: true },
    { name: "Bridal Complete", price: "$399", features: ["Trial Makeup", "Bridal Hair & Makeup", "Luxury Manicure & Pedicure", "Skin Polish"] }
  ];

  return (
    <div className="min-h-screen bg-pink-50 font-sans flex flex-col text-zinc-900 overflow-x-hidden">
      
      {/* Navigation Bar */}
      <header className="h-16 bg-white border-b border-pink-100 flex items-center justify-between px-4 md:px-8 sticky top-0 z-50 shadow-sm flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-pink-500 rounded-full flex items-center justify-center text-white font-bold italic">Z</div>
          <span className="text-xl font-bold tracking-tight text-zinc-900">Zee Beauty <span className="text-pink-500">Salon</span></span>
        </div>
        
        {/* Desktop Nav */}
        <nav className="hidden md:flex gap-6 text-sm font-medium text-zinc-600">
          {navLinks.map((link) => (
            <a key={link.name} href={link.href} className="hover:text-pink-500 transition-colors">
              {link.name}
            </a>
          ))}
        </nav>
        
        <div className="hidden md:block">
          <a href="#book" className="px-5 py-2 inline-block bg-zinc-900 text-white text-xs font-bold uppercase tracking-widest rounded-sm hover:bg-zinc-800 transition-all">
            Book Appointment
          </a>
        </div>

        {/* Mobile Menu Toggle */}
        <button className="md:hidden text-zinc-900" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </header>

      {/* Mobile Nav Dropdown */}
      {mobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden fixed top-16 left-0 right-0 bg-white border-b border-pink-100 z-40 p-4 shadow-lg flex flex-col gap-4"
        >
          {navLinks.map((link) => (
            <a key={link.name} href={link.href} onClick={() => setMobileMenuOpen(false)} className="text-sm font-medium text-zinc-600 hover:text-pink-500 p-2 rounded hover:bg-pink-50">
              {link.name}
            </a>
          ))}
          <a href="#book" onClick={() => setMobileMenuOpen(false)} className="px-5 py-3 text-center bg-pink-500 text-white text-sm font-bold uppercase tracking-widest rounded transition-all">
            Book Appointment
          </a>
        </motion.div>
      )}

      <main className="flex-1 flex flex-col pt-4 md:pt-8 bg-pink-50">
        
        {/* Hero Section */}
        <section id="home" className="max-w-6xl w-full mx-auto px-4 md:px-8 pb-12 md:pb-20 grid md:grid-cols-2 gap-6 md:gap-8 items-stretch pt-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="bg-white p-8 md:p-12 rounded-xl border border-pink-100 relative overflow-hidden shadow-sm flex flex-col justify-center">
            <div className="absolute top-0 right-0 w-48 h-48 bg-pink-100 rounded-full -mr-24 -mt-24 opacity-50"></div>
            <p className="text-pink-500 font-semibold tracking-wider text-xs uppercase mb-3 relative z-10">Premium Salon Experience</p>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-zinc-900 leading-tight mb-6 relative z-10 tracking-tight">
              Enhancing Your <br/><span className="text-pink-500 italic">Natural Beauty</span>
            </h1>
            <p className="text-zinc-500 text-sm md:text-base mb-8 leading-relaxed max-w-md relative z-10">
              Discover the ultimate in relaxation and style. Our expert stylists and estheticians provide tailored beauty treatments designed to make you glow from within.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 relative z-10">
              <a href="#book" className="flex-1 py-3 px-6 text-center bg-pink-500 text-white rounded-lg font-bold text-sm tracking-wide shadow-md shadow-pink-200 hover:bg-pink-600 hover:-translate-y-0.5 transition-all">Book Now</a>
              <a href="#contact" className="flex-1 py-3 px-6 text-center border border-zinc-200 text-zinc-700 rounded-lg font-bold text-sm bg-white hover:bg-zinc-50 hover:-translate-y-0.5 transition-all">Contact Us</a>
            </div>
          </motion.div>
          
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }} className="h-[400px] md:h-auto rounded-xl overflow-hidden relative bg-zinc-200 border border-pink-100 shadow-sm min-h-[400px]">
            <img src="https://images.unsplash.com/photo-1600948836101-f9ffda59d250?auto=format&fit=crop&w=1000&q=80" alt="Salon Styling" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-900/60 via-transparent to-transparent"></div>
          </motion.div>
        </section>

        {/* About Section */}
        <section id="about" className="bg-white border-y border-pink-100 py-16 md:py-24">
          <div className="max-w-6xl mx-auto px-4 md:px-8 grid md:grid-cols-12 gap-8 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="md:col-span-5 h-[300px] md:h-[450px] rounded-xl overflow-hidden bg-pink-100 relative shadow-sm border border-pink-50">
               <img src="https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&w=800&q=80" alt="Beauty Experts" className="w-full h-full object-cover absolute inset-0" />
            </motion.div>
            
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="md:col-span-7 bg-zinc-900 text-white p-8 md:p-12 rounded-xl relative overflow-hidden shadow-lg border border-zinc-800">
               <div className="absolute top-0 right-0 w-64 h-64 bg-pink-600 rounded-full blur-[80px] opacity-20 -mr-20 -mt-20"></div>
               <h3 className="text-3xl tracking-tight font-extrabold mb-4 relative z-10">About Us</h3>
               <p className="text-zinc-400 text-sm md:text-base leading-relaxed mb-8 relative z-10">
                 With over 12 years of excellence in New York, Zee Beauty Salon combines modern techniques with premium organic products to ensure every client leaves feeling glowing and rejuvenated. We believe that caring for your appearance is an essential part of self-care.
               </p>
               <div className="flex items-center gap-4 mt-4 pt-6 border-t border-zinc-800 relative z-10">
                 <div className="flex -space-x-3">
                   <div className="w-12 h-12 rounded-full border-2 border-zinc-900 bg-pink-300 flex items-center justify-center text-zinc-900 shadow-sm"><Star size={20}/></div>
                   <div className="w-12 h-12 rounded-full border-2 border-zinc-900 bg-pink-400 flex items-center justify-center text-zinc-900 shadow-sm"><Heart size={20}/></div>
                   <div className="w-12 h-12 rounded-full border-2 border-zinc-900 bg-pink-500 overflow-hidden shadow-sm"><img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&q=80" alt="Stylist"/></div>
                 </div>
                 <div>
                   <div className="text-sm font-bold text-white tracking-wide">15+ Beauty Experts</div>
                   <div className="text-xs text-pink-400 mt-0.5">Dedicated to your care</div>
                 </div>
               </div>
            </motion.div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-16 md:py-24 max-w-6xl w-full mx-auto px-4 md:px-8">
          <div className="flex justify-between items-end mb-10">
            <div>
              <p className="text-pink-500 font-semibold tracking-wider text-xs uppercase mb-2">What We Do</p>
              <h2 className="text-3xl md:text-4xl font-extrabold text-zinc-900 tracking-tight">Our Services</h2>
            </div>
            <a href="#pricing" className="hidden md:inline-block text-pink-500 text-sm font-bold hover:text-pink-600 uppercase tracking-wide">View Menu</a>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 md:gap-5">
            {services.map((s, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 15 }} 
                whileInView={{ opacity: 1, y: 0 }} 
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="p-6 rounded-xl bg-white border border-pink-100 group hover:bg-pink-500 hover:border-pink-500 hover:-translate-y-1 hover:shadow-lg transition-all duration-300 cursor-default shadow-sm flex flex-col justify-center"
              >
                <div className="w-12 h-12 mb-4 bg-pink-50 rounded-full flex items-center justify-center text-pink-500 shadow-sm group-hover:bg-white group-hover:text-pink-500 transition-colors">
                  {s.icon}
                </div>
                <h4 className="font-bold text-base mb-2 group-hover:text-white transition-colors">{s.title}</h4>
                <p className="text-sm text-zinc-500 group-hover:text-pink-100 transition-colors leading-relaxed">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Gallery Section */}
        <section id="gallery" className="bg-white py-16 md:py-24 border-t border-pink-100">
          <div className="max-w-6xl mx-auto px-4 md:px-8">
             <div className="text-center mb-12">
               <p className="text-pink-500 font-semibold tracking-wider text-xs uppercase mb-2">Our Work</p>
               <h2 className="text-3xl md:text-4xl font-extrabold text-zinc-900 tracking-tight">Salon Gallery</h2>
             </div>
             <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
                {galleryImages.map((img, i) => (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    key={i} 
                    className="bg-zinc-200 rounded-xl overflow-hidden relative aspect-square group shadow-sm border border-pink-50"
                  >
                    <img src={img} alt={`Gallery image ${i + 1}`} className="w-full h-full object-cover transition-transform duration-700 ease-in-out group-hover:scale-110" loading="lazy" />
                    <div className="absolute inset-0 bg-zinc-900/0 group-hover:bg-zinc-900/30 transition-all duration-300 flex items-center justify-center">
                      <Camera className="text-white opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-4 group-hover:translate-y-0" size={32}/>
                    </div>
                  </motion.div>
                ))}
             </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-16 md:py-24 max-w-6xl mx-auto px-4 md:px-8 w-full">
          <div className="text-center mb-12">
            <p className="text-pink-500 font-semibold tracking-wider text-xs uppercase mb-2">Transparent Costs</p>
            <h2 className="text-3xl md:text-4xl font-extrabold text-zinc-900 text-center tracking-tight">Service Pricing</h2>
          </div>
          <div className="grid lg:grid-cols-3 gap-6 items-center">
            {pricing.map((p, i) => (
               <motion.div 
                 initial={{ opacity: 0, y: 20 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true }}
                 transition={{ delay: i * 0.1 }}
                 key={i} 
                 className={`p-8 md:p-10 rounded-2xl border ${p.border || 'border-pink-100'} ${p.bg || 'bg-white'} ${p.text || 'text-zinc-900'} shadow-sm relative flex flex-col ${p.popular ? 'lg:-translate-y-4 shadow-lg lg:scale-105 z-10' : 'z-0'}`}
               >
                  {p.popular && <span className="absolute top-0 right-8 -mt-3 bg-zinc-900 text-white text-[10px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full shadow-sm">Most Popular</span>}
                  <h3 className="text-xl font-bold mb-2 tracking-tight">{p.name}</h3>
                  <div className="text-5xl font-extrabold mb-8 tracking-tighter">{p.price}</div>
                  <ul className={`space-y-4 mb-8 flex-1 ${p.text ? 'text-pink-50' : 'text-zinc-600'} text-sm`}>
                    {p.features.map((f, j) => (
                       <li key={j} className="flex items-center gap-3">
                         <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${p.text ? 'bg-white text-pink-500' : 'bg-pink-100 text-pink-500'}`}><Star size={10} className="fill-current"/></div>
                         {f}
                       </li>
                    ))}
                  </ul>
                  <a href="#book" className={`block w-full py-3.5 text-center rounded-lg font-bold text-sm uppercase tracking-wider transition-all ${p.bg === 'bg-pink-500' ? 'bg-white text-pink-500 hover:bg-zinc-50 hover:shadow-md' : 'bg-pink-50 border border-pink-100 text-pink-600 hover:bg-pink-100'}`}>
                    Choose Plan
                  </a>
               </motion.div>
            ))}
          </div>
        </section>

        {/* Booking & Testimonials */}
        <section className="bg-white border-y border-pink-100 py-16 md:py-24">
          <div id="book" className="max-w-6xl mx-auto px-4 md:px-8 grid md:grid-cols-12 gap-10 items-stretch">
            
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="md:col-span-7 bg-white border border-pink-100 p-6 md:p-10 rounded-2xl shadow-sm flex flex-col">
              <p className="text-pink-500 font-semibold tracking-wider text-xs uppercase mb-2">Book Now</p>
              <h2 className="text-3xl font-extrabold text-zinc-900 mb-8 tracking-tight">Reserve a Spot</h2>
              <form className="flex flex-col gap-5 flex-1 justify-between" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-500 mb-1.5 uppercase tracking-wide">First Name</label>
                    <input type="text" placeholder="e.g. Jessica" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:ring-1 focus:ring-pink-500 focus:border-pink-500 outline-none transition-all placeholder:text-zinc-400" required/>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-zinc-500 mb-1.5 uppercase tracking-wide">Last Name</label>
                    <input type="text" placeholder="e.g. Smith" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:ring-1 focus:ring-pink-500 focus:border-pink-500 outline-none transition-all placeholder:text-zinc-400" required/>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-500 mb-1.5 uppercase tracking-wide">Phone Number</label>
                    <input type="tel" placeholder="(555) 000-0000" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:ring-1 focus:ring-pink-500 focus:border-pink-500 outline-none transition-all placeholder:text-zinc-400" required/>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-zinc-500 mb-1.5 uppercase tracking-wide">Service</label>
                    <select className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:ring-1 focus:ring-pink-500 focus:border-pink-500 outline-none text-zinc-700 appearance-none transition-all" required>
                      <option value="">Select Service</option>
                      <option>Hair Styling</option>
                      <option>Bridal Makeup</option>
                      <option>Facial Spa</option>
                      <option>Manicure & Pedicure</option>
                    </select>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-5">
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-zinc-500 mb-1.5 uppercase tracking-wide">Date</label>
                    <input type="date" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:ring-1 focus:ring-pink-500 focus:border-pink-500 outline-none text-zinc-700 transition-all cursor-pointer" required/>
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-zinc-500 mb-1.5 uppercase tracking-wide">Time</label>
                    <input type="time" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:ring-1 focus:ring-pink-500 focus:border-pink-500 outline-none text-zinc-700 transition-all cursor-pointer" required/>
                  </div>
                </div>
                <button type="submit" className="w-full mt-4 py-4 bg-pink-500 hover:bg-pink-600 text-white rounded-lg font-bold text-sm uppercase tracking-widest shadow-md shadow-pink-200 transition-colors">
                  Confirm Booking
                </button>
              </form>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="md:col-span-5 flex flex-col gap-6">
              <div>
                <p className="text-pink-500 font-semibold tracking-wider text-xs uppercase mb-2">Testimonials</p>
                <h2 className="text-3xl font-extrabold text-zinc-900 mb-2 tracking-tight">Client Reviews</h2>
              </div>
              
              <div className="bg-pink-500 text-white p-6 md:p-8 rounded-2xl shadow-lg relative overflow-hidden flex-1">
                <div className="absolute top-0 right-0 w-32 h-32 bg-pink-400 rounded-full blur-2xl opacity-50 -mr-10 -mt-10 pointer-events-none"></div>
                <div className="flex gap-1 mb-4 text-yellow-300 relative z-10">
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                </div>
                <p className="text-sm md:text-base italic leading-relaxed mb-6 font-medium relative z-10 tracking-wide text-pink-50">
                  "Best facial I've ever had! Sarah was amazing and the environment is so relaxing. The premium glowing treatment really revitalized my skin. 10/10 recommend Zee Beauty Salon!"
                </p>
                <div className="mt-auto flex items-center gap-3 relative z-10">
                  <div className="w-10 h-10 rounded-full border-2 border-pink-300 overflow-hidden bg-pink-600">
                    <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=100&q=80" alt="Client" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <div className="text-sm font-bold tracking-tight">Jessica M.</div>
                    <div className="text-[10px] text-pink-200 uppercase tracking-widest font-semibold mt-0.5">Bride-to-be</div>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-pink-100 p-6 md:p-8 rounded-2xl shadow-sm flex-1">
                <div className="flex gap-1 mb-4 text-yellow-400">
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                  <Star size={16} fill="currentColor" stroke="currentColor"/>
                </div>
                <p className="text-sm md:text-base italic leading-relaxed text-zinc-600 mb-6 font-medium">
                  "The team here is incredible. Got my hair colored and they matched the exact balayage tone I wanted. The salon itself is gorgeous and super clean."
                </p>
                <div className="mt-auto flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center text-pink-500 font-bold border border-pink-200">
                    AL
                  </div>
                  <div>
                    <div className="text-sm font-bold text-zinc-900 tracking-tight">Amanda L.</div>
                    <div className="text-[10px] text-zinc-400 uppercase tracking-widest font-semibold mt-0.5">Regular Client</div>
                  </div>
                </div>
              </div>

            </motion.div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="bg-zinc-900 text-white py-16 md:py-24">
          <div className="max-w-6xl mx-auto px-4 md:px-8 grid md:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <p className="text-pink-500 font-semibold tracking-wider text-xs uppercase mb-2">Reach Out</p>
              <h2 className="text-3xl md:text-4xl font-extrabold mb-6 tracking-tight">Get in Touch</h2>
              <p className="text-zinc-400 text-sm md:text-base leading-relaxed mb-10 max-w-md">
                Have questions about our services or want to book a special event? Reach out to us. We would love to hear from you.
              </p>
              
              <div className="flex flex-col gap-8">
                 <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-zinc-800 border border-zinc-700 rounded-full flex items-center justify-center flex-shrink-0 text-pink-500">
                       <MapPin size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg tracking-tight">Visit Us</h4>
                      <p className="text-zinc-400 text-sm mt-1 leading-relaxed">123 Glamour Ave, Suite 100<br/>New York, NY 10001</p>
                    </div>
                 </div>
                 
                 <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-zinc-800 border border-zinc-700 rounded-full flex items-center justify-center flex-shrink-0 text-pink-500">
                       <Phone size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg tracking-tight">Call Us</h4>
                      <p className="text-zinc-400 text-base mt-1 mb-3">(555) 012-3456</p>
                      <a href="#" className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 transition-colors text-white text-xs font-bold px-4 py-2 rounded-full uppercase tracking-widest shadow-md">
                        <MessageCircle size={14} /> WhatsApp Us
                      </a>
                    </div>
                 </div>
                 
                 <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-zinc-800 border border-zinc-700 rounded-full flex items-center justify-center flex-shrink-0 text-pink-500">
                       <Mail size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg tracking-tight">Email Us</h4>
                      <p className="text-zinc-400 text-sm mt-1">hello@zeebeautysalon.com</p>
                    </div>
                 </div>
              </div>
            </motion.div>
            
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="h-full min-h-[400px] w-full bg-zinc-800 rounded-2xl overflow-hidden relative border border-zinc-700 shadow-xl">
              <div className="absolute inset-0 bg-zinc-800 flex flex-col items-center justify-center text-zinc-500 p-8 text-center m-4 rounded-xl border-2 border-dashed border-zinc-700">
                 <div className="w-16 h-16 bg-zinc-900 rounded-full flex items-center justify-center mb-4">
                   <MapPin size={28} className="text-zinc-600"/>
                 </div>
                 <h4 className="text-lg font-bold text-zinc-400 mb-2">Google Maps</h4>
                 <p className="text-sm max-w-[200px]">Map visualization is ready for API integration.</p>
              </div>
            </motion.div>
          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="bg-black py-8 border-t border-zinc-900 flex-shrink-0">
        <div className="max-w-6xl mx-auto px-4 md:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 opacity-90 transition-opacity hover:opacity-100">
            <div className="w-8 h-8 bg-pink-500 rounded-full flex items-center justify-center text-white font-bold italic text-sm">Z</div>
            <span className="text-xl font-bold tracking-tight text-white">Zee Beauty</span>
          </div>
          
          <div className="text-xs text-zinc-500 text-center font-medium tracking-wide">
            &copy; {new Date().getFullYear()} Zee Beauty Salon. All rights reserved.
          </div>
          
          <div className="flex gap-6">
            <a href="#" className="text-sm text-zinc-500 hover:text-pink-500 transition-colors">Instagram</a>
            <a href="#" className="text-sm text-zinc-500 hover:text-pink-500 transition-colors">Facebook</a>
            <a href="#" className="text-sm text-zinc-500 hover:text-pink-500 transition-colors">Twitter</a>
          </div>
        </div>
      </footer>

      {/* Back to Top */}
      <motion.button 
        className={`fixed bottom-6 right-6 w-12 h-12 bg-zinc-900 border border-zinc-800 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-pink-500 hover:border-pink-500 transition-all duration-300 z-50 ${showTopBtn ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'}`}
        onClick={goToTop}
        aria-label="Back to top"
      >
        <ChevronUp size={24} />
      </motion.button>
    </div>
  );
}

